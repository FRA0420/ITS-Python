#esercizio 3.1 

names: list = ["chiara", "leo", "giulia", "valerio"]
print(names[0])
print(names[1])
print(names[2])
print(names[3])

print(f"Gli invitati alla cena sono {len(names)}")

#esercizio 3.2

print(f"ciao {names[1]}, sono {names[0]}. Sai come sta {names[3]}?")