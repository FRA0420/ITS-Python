#esercizio 3.4

dinner_list: list = ["giulia", "Leo", "Valerio"]

print(f"Ciao {dinner_list[0]}, vuoi venire a cena stasera?")
print(f"Ciao {dinner_list[1]}, vuoi venire a cena stasera?")
print(f"Ciao {dinner_list[2]}, vuoi venire a cena stasera?")