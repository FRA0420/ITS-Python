'''x = float = 1.7
y = 1.0/x
print(y)
print(x*y)
print(x-(x*y))'''

'''x = 5.2
y = x%2 
print(y)
print(f" il valore di x è: {x}\n il valore di y è: {y}")'''

'''x = int(input("Inserisci un numero positivo: "))
y = int(input("Inserisci un numero positivo: "))
z = int(input("Inserisci un numero positivo: "))

media = (x + y + z)/3

print(f"la media è: {media}")'''

'''print("2 \n0 \n2 \n4")'''

t1 = int(input("Dammi una temperatura in gradi Fahrenheit: "))

gradiCelsius = 5*(t1-32)/9
print(f"{t1} gradi Fahrenheit corrispondono a {gradiCelsius:.2f} gradi Celsius")




