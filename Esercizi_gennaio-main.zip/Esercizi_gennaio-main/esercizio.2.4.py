#esercizio 2-4


name:str = "chiara"
print(f"upper: {name.upper()}, lower: {name.lower()}, title: {name.title()}")

name = input("Quale è il tuo nome? ")

print(name.upper())
print(name.lower())
print(name.title())