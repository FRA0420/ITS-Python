#esercizio 6.1

dict1: dict = { "first_name":"Giulia", "last_name":"La Venuta", "age": 26, "city": "Roma"} 

print(dict1)

print(dict1["first_name"])
print(dict1["last_name"])
print(dict1["age"])
print(dict1["city"])