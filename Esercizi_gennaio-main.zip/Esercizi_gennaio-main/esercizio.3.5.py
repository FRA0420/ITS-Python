#esercizio 3.5

dinner_list: list = ["giulia", "Leo", "Valerio"]

print(dinner_list)

dinner_list.pop(2)
print(dinner_list)
dinner_list.append("Valerio")
print(dinner_list)