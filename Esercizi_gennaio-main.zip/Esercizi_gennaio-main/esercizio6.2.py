#esercizio 6.2

dict2: dict = {"k1": 17, "k2": 16, "k3": 19, "k4": 666}

chiara = dict2["k1"]
leo = dict2["k2"]
giulia = dict2["k3"]
ric = dict2["k4"]
print(f" Il numero preferito di Chiara è: {chiara} \nil numero preferito di leo è {leo}, \n il numero preferito di giulia è{giulia}, \nil numero preferito di ric è {ric}")