#esercizio 3.3

transport: list = ["macchina", "moto", "monopattino"]
print(f"mi piace andare in {transport[2]}")