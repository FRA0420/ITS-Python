# esercizio 2.5

print("\"Luke, Im your father\". Cit. Darth Vader")

# esercizio 2.6

famous_person: str = "Darth Vader"
message: str = "\n\"Luke, I'm your father\""
print(f"Once, {famous_person} said: {message}")