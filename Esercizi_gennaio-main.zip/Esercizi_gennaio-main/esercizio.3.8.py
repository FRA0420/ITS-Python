#esercizio 3.8

trips: list = ["Bali", "New York", "Maldive", "Tenerife", "Amsterdam"]

print(trips)

# a.sort() x ordinare la lista

trips2 = sorted(trips, reverse=True)
print(f"{trips2=}")

print(trips)



trips.reverse()
print(trips)

trips.reverse()
print(trips)

trips.sort()
print(trips)

trips.sort(reverse=True)
print(trips)