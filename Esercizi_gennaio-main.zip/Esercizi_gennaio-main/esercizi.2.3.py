#esercizio 2-3

name = input("Quale è il tuo nome? ")

print(f"Allora, {name} sei pronto a fare esercizi in Python oggi?")

name: str = "chiara"
print(f"Ciao {name} come stai?")