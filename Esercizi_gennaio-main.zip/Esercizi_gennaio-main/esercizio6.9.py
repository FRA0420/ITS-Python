#esercizio 6.9

favorites_places:dict= {"chiara":"roma", "leo":"puglia","giulia":"grecia"}
for k,v in favorites_places.items():
    print(k,v)