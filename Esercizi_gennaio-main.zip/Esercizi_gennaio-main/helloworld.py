print("Hello World!!")

valore = int(input("Inserisci un valore"))

